"use client";

import { MegaMenu } from "@/components/ui/Megamenu/MegaMenu";
import Footer from "@/components/Footer";
import HeroSection from "./HeroSection";
import AboutSection from "./AboutSection";
import ServicesSection from "./ServiceSection";
//import { motion } from "framer-motion";
//import { Button } from "@/components/ui/button";
//import Link from "next/link";
import CTASection from "@/components/CTA";

export default function ProductEngineeringPage() {
  return (
    <div className="min-h-screen bg-[#FFFFFF]">
      <MegaMenu />
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="bg-white border-b border-gray-100 px-4 py-3">
        <ol className="max-w-7xl mx-auto flex items-center text-sm text-gray-500 gap-1 flex-wrap">
          <li>
            <a href="/" className="hover:text-[#0098af] transition-colors" aria-label="Home">
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
            </a>
          </li>
          <li aria-hidden="true"><svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg></li>
          <li><a href="/services" className="hover:text-[#0098af] transition-colors">Services</a></li>
          <li aria-hidden="true"><svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg></li>
          <li><span className="text-[#003C46] font-medium" aria-current="page">Product Engineering</span></li>
        </ol>
      </nav>
      <HeroSection />
      <AboutSection />
      <section id="services">
        <ServicesSection />
      </section>

      {/* CTA Section */}
      <CTASection />

      <Footer />
    </div>
  );
}
