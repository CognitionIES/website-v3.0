import React from "react";

import { MegaMenu } from "@/components/ui/Megamenu/MegaMenu";
import Hero from "./HeroSection";
import Footer from "@/components/Footer";
import AboutSection from "./AboutSection";
import Objective from "./ObjectiveSection";
import Scope from "./ScopeSection";
import Outcome from "./OutcomeSection";
import Tech from "./TechSection";
import CTASection from "./CTA";

export default function DigitalizationProject() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F9FAFB] to-[#E5ECEF]">
      <MegaMenu />
      {/* Hero Section */}
      <section className="relative  overflow-hidden">
        <Hero />
      </section>
      <AboutSection />
      <Objective />
      <Scope />
      <Outcome />
      <Tech />
      <CTASection />
      {/* Call to Action Section */} 
      <Footer />
    </div>
  );
}
