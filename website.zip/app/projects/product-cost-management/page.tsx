"use client";

import React from "react";
import Footer from "@/components/Footer";
import { MegaMenu } from "@/components/ui/Megamenu/MegaMenu";
import ProjectCTA from "./ProjectCTA";
import Hero from "./HeroSection";
import AboutSection from "./AboutSection";
import Objectives from "./Objectives";
import ProjectApproach from "./ApproachSection";
import PCMKeyFindings from "./KeyFindingSection";
import SummaryGains from "./SummarySection";

export default function ProductCostManagement() {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <MegaMenu />
      <Hero />
      <AboutSection />
      <Objectives />
      <ProjectApproach />
      <PCMKeyFindings />
      <SummaryGains />
      <ProjectCTA />
      <Footer />
    </div>
  );
}
