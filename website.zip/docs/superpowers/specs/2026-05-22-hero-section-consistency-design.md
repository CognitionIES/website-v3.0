# Hero Section Consistency — Design Spec

**Date:** 2026-05-22  
**Scope:** Unify hero sections across service pages and case study pages to match the Careers/About reference design. Remove all dash decorations.

---

## Problem

Three distinct hero patterns exist across the site, creating visual inconsistency as users navigate between pages:

| Pattern | Pages | Key issues |
|---|---|---|
| Reference (correct) | Careers, About, Projects landing, FAQ, Contact, Brochure | — |
| Service pages | Plant Engineering, Product Engineering | Wrong gradient, no accent/grid/eyebrow/ellipse, dash below title, wrong font |
| Case studies | Digitalization, Product Cost Management | Dash before eyebrow, wrong eyebrow color (#99D5DF vs #0098AF), breadcrumb at bottom, no accent/grid/ellipse, wrong font |

---

## Design Decision: Universal Hero Structure

All hero sections adopt the Careers/About pattern exactly.

### Structure (top to bottom)

```
[1px top accent line — gradient via #0098AF/50]
[dark bg #0f1117 + background image at 35% opacity]
[gradient overlay — from-[#0f1117]/50 via-[#0f1117]/40 to-[#0f1117]/90]
[grid texture — white lines at 4% opacity, 64px grid]
  pt-32 content zone:
    [breadcrumb — Home › Category › Page, text-[12px] text-white/35]
    [eyebrow — "Category · Subcategory", eyebrow text-[#0098AF] class]
    [h1 — font-display text-5xl sm:text-6xl md:text-7xl text-white leading-[1.0] tracking-[-0.03em]]
    [subtitle — mt-4 font-sans text-[16px] text-white/50 max-w-lg leading-[1.75]]
    [meta pills — case study pages only]
  pb-20
[white ellipse clip — h-12, ellipse(55% 100% at 50% 100%)]
```

### Eyebrow format

All pages use `Category · Label`:

- Services pages: `"Services · Plant Engineering"`, `"Services · Product Engineering"`
- Case study pages: `"Projects · Case Study"`
- About: `"About Us"` (already correct)
- Careers: `"Cognition IES · Careers"` (already correct)

### Typography

- H1: `font-display text-5xl sm:text-6xl md:text-7xl text-white leading-[1.0] tracking-[-0.03em]`
- No `font-extrabold` or `tracking-tight` — those are wrong

### Removals

- Plant/Product Engineering: remove `<span className="block mt-2 w-16 h-0.5 bg-gradient-to-r from-[#99D5DF] to-transparent" />`
- Digitalization/PCM: remove `<span className="w-5 h-px bg-[#99D5DF]" />` from eyebrow
- All: replace `h-[400px]` / `h-[420px]` fixed heights with `minHeight: 460`
- All: replace teal gradient (`from-[#003C46]/85 to-[#0098AF]/70`) with dark `#0f1117` base
- Case studies: move breadcrumb from bottom to top-left

### Animations

Match Careers exactly:
- Breadcrumb: `opacity: 0 → 1`, duration 0.4s
- Eyebrow: `opacity: 0 → 1`, duration 0.4s, delay 0.05s
- H1: `opacity: 0, y: 16 → 0`, duration 0.65s, delay 0.1s, ease [0.22, 1, 0.36, 1]
- Subtitle: `opacity: 0 → 1`, duration 0.5s, delay 0.2s
- Meta pills: `opacity: 0 → 1`, duration 0.5s, delay 0.3s

---

## Files to Change

1. `app/services/plant-engineering/HeroSection.tsx` — full rewrite
2. `app/services/product-engineering/HeroSection.tsx` — full rewrite
3. `app/projects/digitalization/HeroSection.tsx` — full rewrite
4. `app/projects/product-cost-management/HeroSection.tsx` — full rewrite

## Files Unchanged

- `app/careers/HeroSection.tsx` — reference, already correct
- `app/about/page.tsx` — reference, already correct
- `components/shared/PageHero.tsx` — reference, already correct
- `app/services/saas-solution/servicecpq/HeroSection.tsx` — white/light variant, intentionally different

---

## What Case Study Pages Keep

Meta pills (tag chips below the subtitle) are a case-study-specific UX element that help users understand the project scope at a glance. They stay — just styled consistently with `bg-white/10 border border-white/15 text-white/70`.
