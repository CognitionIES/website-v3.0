# Hero Section Consistency Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Rewrite 4 hero sections (Plant Engineering, Product Engineering, Digitalization, Product Cost Management) to match the Careers/About reference design: dark `#0f1117` background, top cyan accent, grid texture, `font-display` heading, eyebrow in `#0098AF`, breadcrumb top-left, white ellipse clip at bottom — and remove all dash decorations.

**Architecture:** Each file is a self-contained `"use client"` component that replaces its current implementation entirely. No shared abstractions added — the Careers pattern is already simple enough to copy directly. The existing `PageHero` shared component is NOT used here because service/case-study pages need page-specific content structure (meta pills, CTAs).

**Tech Stack:** Next.js 14 App Router · TypeScript · Tailwind CSS · Framer Motion · next/image · lucide-react

**Reference file (do not modify):** `app/careers/HeroSection.tsx`

---

## File Map

| File | Action | Note |
|---|---|---|
| `app/services/plant-engineering/HeroSection.tsx` | Full rewrite | Remove gradient bar dash, unify pattern |
| `app/services/product-engineering/HeroSection.tsx` | Full rewrite | Same as Plant Engineering |
| `app/projects/digitalization/HeroSection.tsx` | Full rewrite | Remove dash before eyebrow, move breadcrumb to top |
| `app/projects/product-cost-management/HeroSection.tsx` | Full rewrite | Same as Digitalization |

---

## Task 1: Plant Engineering Hero

**Files:**
- Modify: `app/services/plant-engineering/HeroSection.tsx` (full rewrite)

- [ ] **Step 1: Replace the file with the unified hero**

Replace the entire contents of `app/services/plant-engineering/HeroSection.tsx` with:

```tsx
"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { Home, ChevronRight } from "lucide-react";
import HeroImage from "@/constants/images/plant/hero.jpg";

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative overflow-hidden bg-[#0f1117]" style={{ minHeight: 460 }}>
      <Image src={HeroImage} alt="Plant Engineering" fill priority sizes="100vw" quality={85} className="object-cover object-center opacity-35" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f1117]/50 via-[#0f1117]/40 to-[#0f1117]/90" />

      {/* Grid texture */}
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.4) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.4) 1px,transparent 1px)", backgroundSize: "64px 64px" }} />

      {/* Top accent */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#0098AF]/50 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 pt-32 pb-20">
        <motion.nav
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4 }}
          className="flex items-center gap-1.5 font-sans text-[12px] text-white/35 mb-8"
        >
          <Link href="/" className="flex items-center gap-1 hover:text-white/60 transition-colors">
            <Home className="w-3 h-3" /> Home
          </Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <Link href="/services" className="hover:text-white/60 transition-colors">Services</Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <span className="text-[#0098AF]/80">Plant Engineering</span>
        </motion.nav>

        <motion.span
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="eyebrow text-[#0098AF]"
        >
          Services · Plant Engineering
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 16 }} animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-5xl sm:text-6xl md:text-7xl text-white leading-[1.0] tracking-[-0.03em] max-w-2xl mt-4"
        >
          Plant Engineering
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-4 font-sans text-[16px] text-white/50 max-w-lg leading-[1.75]"
        >
          Innovative engineering solutions for complex plant challenges, from concept through commissioning.
        </motion.p>
      </div>

      {/* White clip into next section */}
      <div className="absolute bottom-0 inset-x-0 h-12 z-20 pointer-events-none" style={{ clipPath: "ellipse(55% 100% at 50% 100%)" }}>
        <div className="absolute inset-0 bg-white" />
      </div>
    </section>
  );
}
```

- [ ] **Step 2: Verify in browser**

Navigate to `/services/plant-engineering`. Confirm:
- Dark `#0f1117` background (not teal gradient)
- 1px cyan line at very top of section
- Subtle grid pattern visible
- Breadcrumb: Home › Services › Plant Engineering (top-left, above eyebrow)
- Eyebrow: "Services · Plant Engineering" in cyan
- H1 "Plant Engineering" in large display font, tight tracking
- NO gradient bar / dash below the title
- White ellipse blending into next section at bottom

---

## Task 2: Product Engineering Hero

**Files:**
- Modify: `app/services/product-engineering/HeroSection.tsx` (full rewrite)

- [ ] **Step 1: Replace the file with the unified hero**

Replace the entire contents of `app/services/product-engineering/HeroSection.tsx` with:

```tsx
"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { Home, ChevronRight } from "lucide-react";
import HeroImage from "@/constants/images/product/hero.jpg";

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative overflow-hidden bg-[#0f1117]" style={{ minHeight: 460 }}>
      <Image src={HeroImage} alt="Product Engineering" fill priority sizes="100vw" quality={85} className="object-cover object-center opacity-35" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f1117]/50 via-[#0f1117]/40 to-[#0f1117]/90" />

      {/* Grid texture */}
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.4) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.4) 1px,transparent 1px)", backgroundSize: "64px 64px" }} />

      {/* Top accent */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#0098AF]/50 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 pt-32 pb-20">
        <motion.nav
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4 }}
          className="flex items-center gap-1.5 font-sans text-[12px] text-white/35 mb-8"
        >
          <Link href="/" className="flex items-center gap-1 hover:text-white/60 transition-colors">
            <Home className="w-3 h-3" /> Home
          </Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <Link href="/services" className="hover:text-white/60 transition-colors">Services</Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <span className="text-[#0098AF]/80">Product Engineering</span>
        </motion.nav>

        <motion.span
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="eyebrow text-[#0098AF]"
        >
          Services · Product Engineering
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 16 }} animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-5xl sm:text-6xl md:text-7xl text-white leading-[1.0] tracking-[-0.03em] max-w-2xl mt-4"
        >
          Product Engineering
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-4 font-sans text-[16px] text-white/50 max-w-lg leading-[1.75]"
        >
          Innovative engineering solutions for complex product challenges, from concept through delivery.
        </motion.p>
      </div>

      {/* White clip into next section */}
      <div className="absolute bottom-0 inset-x-0 h-12 z-20 pointer-events-none" style={{ clipPath: "ellipse(55% 100% at 50% 100%)" }}>
        <div className="absolute inset-0 bg-white" />
      </div>
    </section>
  );
}
```

- [ ] **Step 2: Verify in browser**

Navigate to `/services/product-engineering`. Confirm same checklist as Task 1 with Product Engineering content. No gradient bar below the title.

---

## Task 3: Digitalization Case Study Hero

**Files:**
- Modify: `app/projects/digitalization/HeroSection.tsx` (full rewrite)

- [ ] **Step 1: Replace the file with the unified hero**

Replace the entire contents of `app/projects/digitalization/HeroSection.tsx` with:

```tsx
"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { Home, ChevronRight } from "lucide-react";
import engineeringImage from "@/constants/images/projects/digitalization/hero.jpg";

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative overflow-hidden bg-[#0f1117]" style={{ minHeight: 460 }}>
      <Image src={engineeringImage} alt="Digitalization Project" fill priority sizes="100vw" quality={85} className="object-cover object-center opacity-35" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f1117]/50 via-[#0f1117]/40 to-[#0f1117]/90" />

      {/* Grid texture */}
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.4) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.4) 1px,transparent 1px)", backgroundSize: "64px 64px" }} />

      {/* Top accent */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#0098AF]/50 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 pt-32 pb-20">
        <motion.nav
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4 }}
          className="flex items-center gap-1.5 font-sans text-[12px] text-white/35 mb-8"
        >
          <Link href="/" className="flex items-center gap-1 hover:text-white/60 transition-colors">
            <Home className="w-3 h-3" /> Home
          </Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <Link href="/projects" className="hover:text-white/60 transition-colors">Projects</Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <span className="text-[#0098AF]/80">Digitalization</span>
        </motion.nav>

        <motion.span
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="eyebrow text-[#0098AF]"
        >
          Projects · Case Study
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 16 }} animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-5xl sm:text-6xl md:text-7xl text-white leading-[1.0] tracking-[-0.03em] max-w-2xl mt-4"
        >
          Digitalization
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-4 font-sans text-[16px] text-white/50 max-w-lg leading-[1.75]"
        >
          3D scanning, digital twin creation, and real-time data integration for a leading industrial chemical manufacturer.
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-wrap gap-2 mt-6"
        >
          {["Digital Transformation", "Manufacturing", "Industry 4.0"].map((tag) => (
            <span key={tag} className="px-3 py-1 rounded-full bg-white/10 border border-white/15 text-white/70 text-xs font-medium backdrop-blur-sm">
              {tag}
            </span>
          ))}
        </motion.div>
      </div>

      {/* White clip into next section */}
      <div className="absolute bottom-0 inset-x-0 h-12 z-20 pointer-events-none" style={{ clipPath: "ellipse(55% 100% at 50% 100%)" }}>
        <div className="absolute inset-0 bg-white" />
      </div>
    </section>
  );
}
```

- [ ] **Step 2: Verify in browser**

Navigate to `/projects/digitalization`. Confirm:
- Dark background with photo visible at reduced opacity
- 1px cyan accent at top
- Breadcrumb at top-left: Home › Projects › Digitalization (NOT at bottom of hero)
- Eyebrow: "Projects · Case Study" in cyan, NO dash before it
- H1 in large display font
- Meta pills (Digital Transformation, Manufacturing, Industry 4.0) still present
- White ellipse at bottom

---

## Task 4: Product Cost Management Case Study Hero

**Files:**
- Modify: `app/projects/product-cost-management/HeroSection.tsx` (full rewrite)

- [ ] **Step 1: Replace the file with the unified hero**

Replace the entire contents of `app/projects/product-cost-management/HeroSection.tsx` with:

```tsx
"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { Home, ChevronRight } from "lucide-react";

const heroImage = "/images/projects/pcm/hero.jpg";

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <section ref={ref} className="relative overflow-hidden bg-[#0f1117]" style={{ minHeight: 460 }}>
      <Image src={heroImage} alt="Log Splitter Cost Optimisation & Benchmarking" fill priority sizes="100vw" quality={85} className="object-cover object-center opacity-35" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0f1117]/50 via-[#0f1117]/40 to-[#0f1117]/90" />

      {/* Grid texture */}
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.4) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.4) 1px,transparent 1px)", backgroundSize: "64px 64px" }} />

      {/* Top accent */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#0098AF]/50 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-16 pt-32 pb-20">
        <motion.nav
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4 }}
          className="flex items-center gap-1.5 font-sans text-[12px] text-white/35 mb-8"
        >
          <Link href="/" className="flex items-center gap-1 hover:text-white/60 transition-colors">
            <Home className="w-3 h-3" /> Home
          </Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <Link href="/projects" className="hover:text-white/60 transition-colors">Projects</Link>
          <ChevronRight className="w-3 h-3 text-white/20" />
          <span className="text-[#0098AF]/80">Product Cost Management</span>
        </motion.nav>

        <motion.span
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="eyebrow text-[#0098AF]"
        >
          Projects · Case Study
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 16 }} animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-5xl sm:text-6xl md:text-7xl text-white leading-[1.0] tracking-[-0.03em] max-w-2xl mt-4"
        >
          Log Splitter Cost Optimisation & Benchmarking
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-4 font-sans text-[16px] text-white/50 max-w-lg leading-[1.75]"
        >
          Value engineering and competitive benchmarking to achieve 35% cost reduction and 50% margin improvement.
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-wrap gap-2 mt-6"
        >
          {["Product Cost Management", "Value Engineering", "VAVE"].map((tag) => (
            <span key={tag} className="px-3 py-1 rounded-full bg-white/10 border border-white/15 text-white/70 text-xs font-medium backdrop-blur-sm">
              {tag}
            </span>
          ))}
        </motion.div>
      </div>

      {/* White clip into next section */}
      <div className="absolute bottom-0 inset-x-0 h-12 z-20 pointer-events-none" style={{ clipPath: "ellipse(55% 100% at 50% 100%)" }}>
        <div className="absolute inset-0 bg-white" />
      </div>
    </section>
  );
}
```

- [ ] **Step 2: Verify in browser**

Navigate to `/projects/product-cost-management`. Confirm:
- Same visual pattern as Digitalization
- Breadcrumb at top: Home › Projects › Product Cost Management
- Eyebrow: "Projects · Case Study" in cyan, no dash
- H1: "Log Splitter Cost Optimisation & Benchmarking" in large display font
- Meta pills: Product Cost Management, Value Engineering, VAVE
- White ellipse clip at bottom

---

## Final Cross-Page Check

- [ ] Visit all 6 hero pages back-to-back and confirm they look identical in structure: `/about`, `/careers`, `/services/plant-engineering`, `/services/product-engineering`, `/projects/digitalization`, `/projects/product-cost-management`
- [ ] Confirm the SaaS/CPQ hero (`/services/saas-solution`) was NOT changed (it's an intentionally different light variant)
